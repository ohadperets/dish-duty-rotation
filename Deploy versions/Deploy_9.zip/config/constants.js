// Application Constants
export const BROTHERS = {
    'Yonatan': '👨‍💼',
    'Ohad': '👨‍💻',
    'Raz': '👨‍🎓',
    'Yuval': '👨‍🔬'
};

export const STORAGE_KEYS = {
    production: 'dishHistory',
    test: 'dishHistory_test'
};

export const ADMIN_PASSWORD = 'Op0544756518';
export const SECURITY_ANSWER = 'hadar';
export const BLOCK_DURATION = 20; // seconds

export const DAY = {
    SUNDAY: 0,
    MONDAY: 1,
    TUESDAY: 2,
    WEDNESDAY: 3,
    THURSDAY: 4,
    FRIDAY: 5,
    SATURDAY: 6
};
